import notify2
notify2.init('dbus_test')

import time
time.sleep(2)
print('---------- Initialised notifications -----------------')

n = notify2.Notification("Test notification",
                         "hello there"
                        )
n.show()
